You can place your resource (*.brf) files in this folder
 and make the game read them by putting a load_module_resource
directive in module_info.txt

